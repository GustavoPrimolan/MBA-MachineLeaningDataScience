library(bnlearn)
library(bnviewer)

dados.vendas <- read.csv("food-sp.csv", header=TRUE)
dados.vendas = as.data.frame(dados.vendas)

dados.vendas[is.na(dados.vendas)] <- 0
dados.vendas$PROJETO.CAFE[dados.vendas$PROJETO.CAFE == 0] <- mean(dados.vendas$PROJETO.CAFE)
dados.vendas$BRINDE[dados.vendas$BRINDE == 0] <- mean(dados.vendas$BRINDE)

dados.vendas = dados.vendas[, c(
                                'GELADO.E.MILK.SHAKE',
                                'SANDUICHE',
                                'BEBIDA',
                                'ACOMPANHAMENTO',
                                'ADICIONAL',
                                'PROJETO.CAFE',
                                'BRINDE',
                                'PRATO',
                                'VENDA'
                               )]
#ANALISAR DISTRIBUIÇÃO DE PROBABILIDADE DE TODAS AS VARIÁVEIS


#CRIAR UMA REDE BAYESIANA - FUNÇÃO VIEWER


#ANALISAR NÓS MAIS IMPORTANTES - FUNÇÃO VIEWER
